import React from "react";
import FAB from "./fab";
import ChatWindow from "./chat_window";

function Index() {
  return (
    <div>
      <ChatWindow />
      <FAB />
    </div>
  );
}

export default Index;
